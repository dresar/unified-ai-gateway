# Deploy API ke Railway

## Prasyarat

- PostgreSQL: tambah plugin **PostgreSQL** di project Railway, atau set `DATABASE_URL` ke Neon / host lain.
- Set variabel wajib: `JWT_SECRET`, `DATABASE_URL`, `NODE_ENV=production`.
- Set `CORS_ORIGINS` ke URL frontend (pisahkan koma), contoh: `https://app-kamu.vercel.app`.

## Opsi A — Root directory `server` (hanya folder backend)

Di [Railway](https://railway.com/new): **New project** → **Deploy from GitHub** → pilih repo ini → pada service, **Settings → Root Directory** = `server`.

- **Start command:** `npm start` (default dari `package.json`).
- **Release command (disarankan):** `npm run migrate` agar schema DB selaras sebelum traffic.
- **Variables:** salin dari [`server/.env.example`](./.env.example) dan isi nilai production.

Railway menyuntikkan `PORT` otomatis; aplikasi membaca `process.env.PORT`.

## Opsi B — Root repo (npm workspaces)

Jika install harus memakai lockfile di root monorepo:

- **Root Directory:** `.` (kosongkan atau root repo).
- **Install:** `npm ci`
- **Start:** `npm run start -w unified-ai-gateway-server`

## Setelah deploy

- Cek `GET https://<domain-railway>/ping` dan `GET /healthz`.
- Di frontend, set base URL API (mis. `VITE_API_BASE_URL`) ke URL publik Railway.

Deploy ke **cPanel** (PostgreSQL, Node long-running): lihat [`CPANEL.md`](./CPANEL.md) dan [`.env.cpanel.example`](./.env.cpanel.example).
