# Deploy backend ke cPanel (PostgreSQL)

## Yang perlu Anda pahami

- cPanel menjalankan **Node.js sebagai proses jangka panjang** (Passenger / PM2), bukan “serverless” seperti Lambda. Untuk API gateway ini itu **menguntungkan**: pool PostgreSQL stabil dan respons lebih konsisten.
- **Jangan** set `RUNTIME=serverless` atau variabel Vercel/AWS Lambda kecuali Anda sengaja meniru environment serverless; untuk cPanel biarkan Node normal.

## Prasyarat

- PostgreSQL: database di cPanel atau host eksternal (satu `DATABASE_URL` — lihat [`server/.env.cpanel.example`](./.env.cpanel.example)).
- Node **20+** (sesuai `engines` di [`package.json`](./package.json)).
- Domain/subdomain atau reverse proxy ke aplikasi Node.

## Langkah ringkas

1. **Application root** = folder [`server/`](./) (upload repo atau hanya salinan backend).
2. **Install:** dari SSH di folder `server/`: `npm ci` atau `npm install`.
3. **Environment:** salin [`server/.env.cpanel.example`](./.env.cpanel.example) ke `.env` produksi (atau set variabel di UI cPanel). Isi `DATABASE_URL`, `JWT_SECRET`, `CORS_ORIGINS`. Set `NODE_ENV=production`.
4. **Migrasi sekali** (disarankan `ENABLE_RUNTIME_MIGRATIONS=false`): `npm run migrate`
5. **Startup file:** [`index.js`](./index.js) — `PORT` biasanya dari panel; kosongkan `PORT` di `.env` jika cPanel menyuntikkan otomatis.
6. **Restart** aplikasi dari cPanel; uji `GET /ping` dan `GET /healthz`.

## Keamanan

- Rotasi password database dan `JWT_SECRET` jika secret pernah bocor.
- Jangan commit `.env`.

## Referensi lain

- Deploy cloud alternatif: [`RAILWAY.md`](./RAILWAY.md)
